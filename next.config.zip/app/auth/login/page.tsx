import { LoginPage } from "@/app/views/LoginPage/LoginPage";


export default function Login() {
    return (
        <LoginPage />
    )
}