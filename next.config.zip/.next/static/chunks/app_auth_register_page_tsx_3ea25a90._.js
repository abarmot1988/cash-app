(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_views_RegisterPage_RegisterPage_module_5c6a865f.css",
  "static/chunks/app_views_RegisterPage_ce67e2bc._.js"
],
    source: "dynamic"
});
