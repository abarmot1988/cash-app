(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_views_LoginPage_LoginPage_module_4b713095.css",
  "static/chunks/app_views_LoginPage_48acf470._.js"
],
    source: "dynamic"
});
