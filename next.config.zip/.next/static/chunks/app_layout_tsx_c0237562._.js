(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9d126714._.css",
  "static/chunks/node_modules_43dab84f._.js",
  "static/chunks/app_context_AuthContext_tsx_0af64a21._.js"
],
    source: "dynamic"
});
