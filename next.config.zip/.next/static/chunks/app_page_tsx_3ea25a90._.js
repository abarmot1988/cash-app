(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_page_module_24d20b32.css",
  "static/chunks/app_ff66925e._.js"
],
    source: "dynamic"
});
