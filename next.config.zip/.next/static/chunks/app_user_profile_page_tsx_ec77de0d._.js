(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_views_ProfilePage_ProfilePage_module_c8adec5a.css",
  "static/chunks/node_modules_recharts_es6_e3ed2625._.js",
  "static/chunks/node_modules_acf57056._.js",
  "static/chunks/app_abbafd75._.js"
],
    source: "dynamic"
});
