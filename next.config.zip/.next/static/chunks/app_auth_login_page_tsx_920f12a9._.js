(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_b6b7fcf6._.js",
  "static/chunks/app_views_LoginPage_LoginPage_module_4b713095.css"
],
    source: "dynamic"
});
