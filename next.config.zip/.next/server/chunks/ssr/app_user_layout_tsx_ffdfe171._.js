module.exports = {

"[project]/app/user/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
// "use client";
// import { ReactNode, useEffect } from "react";
// import { useRouter } from "next/navigation";
// import { useAuth } from "../context/AuthContext";
// export default function ProtectedLayout({ children }: { children: ReactNode }) {
//   const { user, loading, isInitialized } = useAuth();
//   const router = useRouter();
//   useEffect(() => {
//   if (isInitialized && !user) {
//     router.replace("/auth/login");
//   }
// }, [isInitialized, user]);
// if (!isInitialized || loading) return <p>Загрузка...</p>;
// if (!user) return null;
// return <>{children}</>;
// }
}}),

};

//# sourceMappingURL=app_user_layout_tsx_ffdfe171._.js.map